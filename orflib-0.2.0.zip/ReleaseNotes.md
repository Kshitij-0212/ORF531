ORFLIB Release Notes
====================

VERSION 0.2.0
-------------

### Additions

1. New file `orflib/exception.hpp`.  
	Definition of orf::Exception class and the ORF_ASSERT macro.

2. New folder `orflib/math/stats` to contain statistics related source files.

3. New files `orflib/math/stats/errorfunction.hpp` and `errorfunction.cpp`.  
	Definition of class ErrorFunction.

4. New files `orflib/math/stats/univariatedistribution.hpp` and `normaldistribution.hpp`.  
	Definition of `UnivariateDistribution` and `NormalDistribution` classes.

5. New folder `orflib/math/pricers` to contain pricing related source files.

6. New files `orflib/math/pricers/simplepricers.hpp` and `simplepricers.cpp`.  
	Definition of the functions fwdPrice(), digitalOptionBS() and europeanOptionBS().

7. In file `pyorflib/pyfunctions0.hpp` added functions:  
    pyOrfErf(), pyOrfInvErf(), pyOrfNormalCdf(), pyOrfNormalInvCdf()
 
8. New file `pyorflib/pyfunctions1.hpp`.  
	Added definition of the following functions:  
	pyOrfFwdPrice(), pyOrfDigiBS() and pyOrfEuroBS().

9. In file `pyorflib/oprlib/__init__.py` added Python callable functions:   
	orf.normalCdf, orf.normalInvCdf, orf.fwdPrice, orf.digiBS, orf.euroBS.


### Modifications

1. Removed unnecessary file `orflib/empty.cpp`


VERSION 0.1.0
-------------

### Additions

1. Top level CMakeLists.txt file with projet-wide settings

2. New folder `orflib` with CMakeLists.txt and start-up code for the core library.

3. New folder `pyorflib` with CMakeLists.txt and start-up code for the Python interface.

4. This release notes file.

5. `.gitignore` file for managing which files to keep under revision control.
